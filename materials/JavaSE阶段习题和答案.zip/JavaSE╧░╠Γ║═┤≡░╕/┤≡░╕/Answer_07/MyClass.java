package chp7;

public class MyClass {
	private int count = 0;
	public MyClass(){
		count ++;
	}
	public int getCount(){
		return count;
	}
}
