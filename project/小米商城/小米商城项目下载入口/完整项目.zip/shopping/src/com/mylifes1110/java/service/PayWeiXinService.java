package com.mylifes1110.java.service;

import com.mylifes1110.java.bean.WeiXin;

public interface PayWeiXinService {
    boolean selectOrderMoney(WeiXin weiXin);
}
